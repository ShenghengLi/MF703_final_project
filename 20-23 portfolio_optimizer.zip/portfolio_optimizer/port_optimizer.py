import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

#Mean-Variance Optimization
def MVO(curr_ret,weight_para):
    mean_returns = curr_ret.mean()
    cov_matrix = curr_ret.cov()
    num_assets = len(curr_ret.columns)
    #print(num_assets)
    initial_weights = np.ones(num_assets) / num_assets
    # minimize negative portfolio returns
    def negative_port_ret(weights):
        return -np.sum(mean_returns * weights)
    
    def port_VaR(weights):
        #print(np.dot(weights.T, np.dot(cov_matrix, weights)))
        return np.dot(weights.T, np.dot(cov_matrix, weights))
    
    # min and max weight of a single stock
    min_weight = -weight_para
    max_weight = weight_para
    bounds = tuple((min_weight, max_weight) for _ in range(num_assets))

    # max variance 
    max_var = weight_para/252
    # constraints
    weight_sum_constraint = {'type': 'eq', 'fun': 
                             lambda weights: np.sum(weights) - 1}
    risk_constraint = {'type': 'ineq', 'fun': 
                       lambda weights: max_var - port_VaR(weights)}
    # Perform MVO optimization
    result = minimize(negative_port_ret, initial_weights, 
                      method='SLSQP', bounds=bounds, 
                      constraints=[weight_sum_constraint,risk_constraint])
    return result.x

def runStrategy(real_logret, pred_logret, window_size, weight_para):
    logret_list = []
    normal_logret_list = []
    optimized_weights_list = []
    portfolio_ret = 1
    normal_portfolio_ret = 1
        
    # normal MVO strategy
    for i in range(window_size+1, len(real_logret.index)):
        normal_curr_ret = real_logret.iloc[i-window_size-1:i-1]
        normal_optimized_weights = MVO(normal_curr_ret,weight_para)
        normal_logret = np.dot(real_logret.iloc[i],normal_optimized_weights)
        normal_logret_list.append(normal_logret)
    
    normal_simple_ret_list = np.exp(normal_logret_list)-1
    for normal_ret in normal_simple_ret_list:
        normal_portfolio_ret *= (1+normal_ret)
    normal_portfolio_ret -= 1
        
    # our strategy
    for j in range(window_size,len(real_logret.index)):
        past_ret = real_logret.iloc[j-window_size:j-1]
        #print(past_ret)
        pred_ret = pred_logret.iloc[j-1:j]
        #print(pred_ret)
        curr_ret = pd.concat([past_ret,pred_ret])
        #print(curr_ret)
        optimized_weights = MVO(curr_ret,weight_para)
        optimized_weights_list.append(optimized_weights)
        logret = np.dot(real_logret.iloc[j],optimized_weights)
        logret_list.append(logret)
            
        #print(pred_ret.index)
    #returns and annualized returns
    simple_ret_list = np.exp(logret_list)-1
    for ret in simple_ret_list:
        portfolio_ret *= (1+ret)
    portfolio_ret -= 1

    # VaR and CVaR analysis
    port_VaR = np.percentile(simple_ret_list, 100 * (1-alpha)) * value_invested
    port_VaR_ret = port_VaR / value_invested
        
    port_CVaR = np.nanmean(simple_ret_list[simple_ret_list 
                                                    < port_VaR_ret]) * value_invested
    port_CVaR_ret = port_CVaR / value_invested
        
    # grpah for VaR and CVaR analysis
    plt.hist(simple_ret_list)
    plt.axvline(port_VaR_ret, color='red', linestyle='solid')
    plt.axvline(port_CVaR_ret, color='red', linestyle='dashed')
    plt.legend(['VaR', 'CVaR', 'Returns'])
    plt.title(f'{window_size}-day Estimation Window with {weight_para} Parameters')
    plt.xlabel('Return')
    plt.ylabel('Observation Frequency')
    plt.show()

    # Print out the report
    normal_portfolio_ret = round(normal_portfolio_ret,4)
    portfolio_ret = round(portfolio_ret,4)
    port_VaR_ret = round(port_VaR_ret,4)
    port_CVaR_ret = round(port_CVaR_ret,4)
    print(f"{window_size}-day estimation window with {weight_para} parameters:")
    print(f" MVO without Strategy Return: {normal_portfolio_ret}")
    print(f"  Strategy Return: {portfolio_ret}")
    print(f"  Strategy VaR Return: {port_VaR_ret}")
    print(f"  Strategy CVaR Return: {port_CVaR_ret}")
    #optimal_weights_df = pd.DataFrame(optimized_weights_list)
    #print(optimal_weights_df)

if __name__ == "__main__":
    # set up constants
    window_size_list = [90]
    weight_para_list = [0.25]
    value_invested = 1
    alpha = 0.95
    
    real_df = pd.read_csv("testing log return.csv").iloc[19:,:].fillna(0)
    pred_df = pd.read_csv("prediction log return.csv")
    
    real_logret = real_df[real_df.columns[1:]].iloc[:,:]
    pred_logret = pred_df[pred_df.columns[1:]].iloc[:,:]
    
    # run the strategy
    for window_size in window_size_list:
        for weight_para in weight_para_list:
            runStrategy(real_logret, pred_logret, window_size, weight_para)
